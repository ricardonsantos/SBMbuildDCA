Automatic protocol to generate input for protein folding simulations using structure-based models and coevolutionary information. 
